/*  此程式碼參照陳鍾誠老師  並進行部分修改 我能大部分理解此程式碼  
    以下有更詳細的註解  */
const Shop =
{
    name:'多喝水',
    address:'金門縣金寧鄉大學路1號',
    tel:'082-999999',
    items:{'柳橙汁':30,'咖啡':50,'冰水':10},
    addons:{'去冰':0,'半糖':0,'熱':0,'小玩具':10},
    orderCount:0,
}
Shop.html =
`
<div>
    <button class="big" onclick="Pos.start()">新增訂單</button><br/><br/>
    <button class="big" onclick="Report.start()">本日報表</button><br/><br/>
    <button class="big" onclick="Setting.start()">商店設定</button><br/><br/>
</div>
`
Shop.start = function () {
    Shop.init()
    Shop.name = localStorage.getItem('Shop.name') || Shop.name
    Shop.address = localStorage.getItem('Shop.address') || Shop.address
    Shop.tel = localStorage.getItem('Shop.tel') || Shop.tel
    Ui.id('menuShopName').innerHTML = Shop.name
    const itemsJson = localStorage.getItem('Shop.items')
    const addonsJson = localStorage.getItem('Shop.addons')
    if (itemsJson != null) Shop.items = JSON.parse(itemsJson)
    if (addonsJson != null) Shop.addons = JSON.parse(addonsJson)
    Ui.show(Shop.html)
  }
/*Shop.start = function(){
    Shop.init()
    Shop.name = localStorage.getItem('Shop.name')||Shop.name/* 如果有localstorage就取他 沒有就原本的name 
    Shop.address = localStorage.getItem('Shop.address') || Shop.address/* 如果有localstorage就取他 沒有就原本的address 
    Shop.tel = localStorage.getItem('Shop.tel') || Shop.tel
    Ui.id('menuShopName').innerHTML = Shop.name
    const itemsJson = localStorage.getItem('Shop.items')
    const addonsJson = localStorage.getItem('Shop.addons')
    if(itemsJson !=null)Shop.items = JSON.parse(itemsJson)/* 將所儲存的localstorage取出使用 
    if (addonsJson != null) Shop.addons = JSON.parse(addonsJson)
    Ui.show(Shop.html)

}*/


Shop.init = function () {
    Shop.orderCount = localStorage.getItem('Pos.Order.count')
    if (Shop.orderCount == null) {
      Shop.orderCount = 0
      localStorage.setItem('Pos.Order.count', Shop.orderCount)
    }
  }
/*Shop.init = function(){/* 價錢無或歸零 
    Shop.orderCount = localStorage.getItem('Pos.Order.count')
    if(Shop.orderCount == null){
        Shop.orderCount = 0
        localStorage.setItem('Pos.Order.count',Shop.orderCount)
    }
    
}*/

Shop.incCount = function () {
    // let orderCount = parseInt(localStorage.getItem('Pos.Order.count')) + 1
    localStorage.setItem('Pos.Order.count', ++ Shop.orderCount)
  }

/*Shop.incCount = function(){/* 對所下訂單進行計算 
    localStorage.setItem('Pos.Order.count',++Shop.orderCount,)
    //++Shop.orderCount --> orderCount = parseInt(localStorage.getItem('Pos.Order.count')) + 1
}*/


Shop.saveOrder = function (Order) {
    localStorage.setItem('Pos.Order.' + Shop.orderCount, JSON.stringify(Order))
  }



/*Shop.saveOrder = function(Order){/* 儲存訂單 
    localStorage.setItem('Pos.Order.'+ Shop.orderCount,JSON.stringify(Order))
    /* 此程式碼尚有部分未理解--> JSON.stringify(Order)
}*/


Shop.getOrder = function (i) {
    let orderJson = localStorage.getItem('Pos.Order.'+i)
    if (orderJson == null) return null
    return JSON.parse(orderJson)
  }
/*Shop.getOrder = function(i){ /* 將saveOrder-->orderJson並傳回值 
    let orderJson = localStorage.getItem('Pos.Order.'+i)
    if(orderJson==null) return null 
    return JSON.parse(orderJson)
}*/